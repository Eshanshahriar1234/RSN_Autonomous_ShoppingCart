#!/usr/bin/env python3
# stuck_detector_node.py
# Full code inserted earlier
