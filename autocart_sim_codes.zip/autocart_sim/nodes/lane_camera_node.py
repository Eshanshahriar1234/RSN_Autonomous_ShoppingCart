#!/usr/bin/env python3
# lane_camera_node.py
# Full code inserted earlier
