#!/usr/bin/env python3
# waypoint_nav_node.py
# Full code inserted earlier
