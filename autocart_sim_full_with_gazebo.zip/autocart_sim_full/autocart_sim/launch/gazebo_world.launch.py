import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    pkg_share = get_package_share_directory('autocart_sim')
    world_path = os.path.join(pkg_share, 'worlds', 'stopandshop_brigham.world')
    cart_urdf = os.path.join(pkg_share, 'models', 'cart.urdf')

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [os.path.join(get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')]
        ),
        launch_arguments={'world': world_path}.items()
    )

    spawn_cart = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-entity', 'autocart', '-file', cart_urdf, '-x', '0', '-y', '0', '-z', '0.1'],
        output='screen'
    )

    bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_share, 'launch', 'cart_bringup.launch.py')
        )
    )

    return LaunchDescription([
        gazebo,
        spawn_cart,
        bringup
    ])
